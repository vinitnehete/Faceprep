import { useEffect, useState } from "react";
import "./styles.css";

export default function App() {
  const [state, setState] = useState([]);
  const [count, setCount] = useState(0);
  const [ind, setInd] = useState(null);

  const random = async () => {
    const res = await fetch("https://randomuser.me/api/?results=10&page=1"); // Fix the URL
    const result = await res.json();
    setState(result.results);
  };

  useEffect(() => {
    random();
  }, []);

  const handleClick = (index) => {
    setCount((prev) => prev + 1);
    setInd(index);
    console.log(index);
    if (index !== ind) {
      setCount(0);
    }
  };

  return (
    <div className="App">
      <div>
        {state.map((item, index) => (
          <div key={index}>
            <li>{item.name.first}</li>
            <div>{index === ind ? count : 0}</div>
            <button onClick={() => handleClick(index)}>Click Me</button>
          </div>
        ))}
      </div>
    </div>
  );
}
